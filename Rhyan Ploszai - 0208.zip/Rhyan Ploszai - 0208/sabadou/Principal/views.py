from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'home/Atividade.html')

def Sergipe(request):
    return render(request, 'home/Sergipe.html')

def Galeria(request):
    return render(request, 'home/Galeria.html')

def Eminem(request):
    return render(request, 'home/Eminem.html')

from django.shortcuts import render, redirect, get_object_or_404
from .models import Colaborador
from .forms import ColaboradorForm

# Listar colaboradores
def lista_colaboradores(request):
    colaboradores = Colaborador.objects.all()
    return render(request, 'home/lista_colaboradores.html', {'colaboradores': colaboradores})

# Criar novo colaborador
def criar_colaborador(request):
    if request.method == 'POST':
        form = ColaboradorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_colaboradores')
    else:
        form = ColaboradorForm()
    return render(request, 'home/form_colaborador.html', {'form': form})

# Editar colaborador
def editar_colaborador(request, id):
    colaborador = get_object_or_404(Colaborador, id=id)
    if request.method == 'POST':
        form = ColaboradorForm(request.POST, instance=colaborador)
        if form.is_valid():
            form.save()
            return redirect('lista_colaboradores')
    else:
        form = ColaboradorForm(instance=colaborador)
    return render(request, 'home/form_colaborador.html', {'form': form})

# Excluir colaborador
def excluir_colaborador(request, id):
    colaborador = get_object_or_404(Colaborador, id=id)
    colaborador.delete()
    return redirect('lista_colaboradores')
