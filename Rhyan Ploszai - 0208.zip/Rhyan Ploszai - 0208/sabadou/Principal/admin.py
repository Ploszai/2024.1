from django.contrib import admin

# Register your models here.
from .models import Colaborador

@admin.register(Colaborador)
class ColaboradorAdmin(admin.ModelAdmin):
    list_display = ('nome', 'cpf', 'cargo', 'telefone', 'email', 'data_admissao')
    search_fields = ('nome', 'cpf', 'cargo')
