import sqlite3

DB_PATH = 'database.db'

schema = '''
CREATE TABLE IF NOT EXISTS colaboradores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    funcao TEXT,
    setor TEXT,
    matricula TEXT
);
'''

conn = sqlite3.connect(DB_PATH)
conn.executescript(schema)
conn.commit()
conn.close()
print('Banco inicializado:', DB_PATH)
