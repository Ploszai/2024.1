from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

DB_PATH = 'database.db'

app = Flask(__name__)
app.secret_key = 'troque-esta-chave-por-uma-segura'

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return redirect(url_for('listar_colaboradores'))

@app.route('/colaboradores')
def listar_colaboradores():
    conn = get_db_connection()
    colaboradores = conn.execute('SELECT * FROM colaboradores').fetchall()
    conn.close()
    return render_template('list.html', colaboradores=colaboradores)

@app.route('/colaborador/novo', methods=('GET','POST'))
def novo_colaborador():
    if request.method == 'POST':
        nome = request.form['nome'].strip()
        funcao = request.form['funcao'].strip()
        setor = request.form['setor'].strip()
        matricula = request.form['matricula'].strip()
        if not nome:
            flash('Nome é obrigatório.')
        else:
            conn = get_db_connection()
            conn.execute(
                'INSERT INTO colaboradores (nome, funcao, setor, matricula) VALUES (?, ?, ?, ?)',
                (nome, funcao, setor, matricula)
            )
            conn.commit()
            conn.close()
            flash('Colaborador criado com sucesso.')
            return redirect(url_for('listar_colaboradores'))
    return render_template('form.html', colaborador=None, action='Criar')

@app.route('/colaborador/<int:id>')
def ver_colaborador(id):
    conn = get_db_connection()
    colaborador = conn.execute('SELECT * FROM colaboradores WHERE id = ?', (id,)).fetchone()
    conn.close()
    if colaborador is None:
        flash('Colaborador não encontrado.')
        return redirect(url_for('listar_colaboradores'))
    return render_template('detail.html', colaborador=colaborador)

@app.route('/colaborador/<int:id>/editar', methods=('GET','POST'))
def editar_colaborador(id):
    conn = get_db_connection()
    colaborador = conn.execute('SELECT * FROM colaboradores WHERE id = ?', (id,)).fetchone()
    if colaborador is None:
        conn.close()
        flash('Colaborador não encontrado.')
        return redirect(url_for('listar_colaboradores'))
    if request.method == 'POST':
        nome = request.form['nome'].strip()
        funcao = request.form['funcao'].strip()
        setor = request.form['setor'].strip()
        matricula = request.form['matricula'].strip()
        if not nome:
            flash('Nome é obrigatório.')
        else:
            conn.execute(
                'UPDATE colaboradores SET nome = ?, funcao = ?, setor = ?, matricula = ? WHERE id = ?',
                (nome, funcao, setor, matricula, id)
            )
            conn.commit()
            conn.close()
            flash('Colaborador atualizado com sucesso.')
            return redirect(url_for('ver_colaborador', id=id))
    conn.close()
    return render_template('form.html', colaborador=colaborador, action='Editar')

@app.route('/colaborador/<int:id>/deletar', methods=('POST',))
def deletar_colaborador(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM colaboradores WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash('Colaborador removido.')
    return redirect(url_for('listar_colaboradores'))

if __name__ == '__main__':
    app.run(debug=True)
