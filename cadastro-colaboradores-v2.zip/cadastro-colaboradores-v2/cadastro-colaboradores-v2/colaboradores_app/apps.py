from django.apps import AppConfig
class ColaboradoresAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'colaboradores_app'
